// Script to open and close sidebar
function w3_open() {
  document.getElementById('mySidebar').style.display = 'block';
  //change background
  document.getElementById('mySidebar').style.backgroundColor='gray';
}

function w3_close() {
  document.getElementById('mySidebar').style.display = 'none';
  
}

//script manipulasi warna background footer
let about = document.querySelector("footer").style.backgroundColor="gray";

// script event  untuk judul sidebar
function mailOver() {
  document.getElementById("mail").style.color = "red";
}
function mailLeave() {
    document.getElementById("mail").style.color = "black";
}
function foodOver() {
  document.getElementById("my-food").style.color = "red";
}
function foodLeave() {
    document.getElementById("my-food").style.color = "black";
}

//script event untuk nama makanan
function sandwOver() {
  document.getElementById("sandw").innerHTML="Price is $30";
}
function sandwLeave() {
    document.getElementById("sandw").innerHTML="The Perfect Sandwich, A Real NYC Classic";
}
function steakOver() {
  document.getElementById("steak").innerHTML="Price is $30";
}
function steakleave() {
    document.getElementById("steak").innerHTML="Let Me Tell You About This Steak";
}

function cheriesOver() {
  document.getElementById("cheries").innerHTML="Price is $30";
}
function cheriesLeave() {
    document.getElementById("cheries").innerHTML="The Perfect Sandwich, A Real NYC Classic";
}
function wineOver() {
  document.getElementById("wine").innerHTML="Price is $30";
}
function wineLeave() {
  document.getElementById("wine").innerHTML="The Perfect Sandwich, A Real NYC Classic";
}
function iceOver() {
  document.getElementById("ice").innerHTML="Price is $30";
}
function iceLeave() {
  document.getElementById("ice").innerHTML="The Perfect Sandwich, A Real NYC Classic";
}
function salmonOver() {
  document.getElementById("salmon").innerHTML="Price is $30";
}
function salmonLeave() {
  document.getElementById("salmon").innerHTML="The Perfect Sandwich, A Real NYC Classic";
}
function classicsandwOver() {
  document.getElementById("classicsandw").innerHTML="Price is $30";
}
function classicsandwLeave() {
  document.getElementById("classicsandw").innerHTML="The Perfect Sandwich, A Real NYC Classic";
}
function frenchOver() {
  document.getElementById("french").innerHTML="Price is $30";
}
function frenchLeave() {
  document.getElementById("french").innerHTML="The Perfect Sandwich, A Real NYC Classic";
}

//script event untuk gambar makanan
function changeNewImages1() {
  let inContents1 = document.getElementById('img-1');
  inContents1.src = './img/price.png';

}
function backToOldImage1() {
  let inContents1 = document.getElementById('img-1');
  inContents1.src = 'https://www.w3schools.com/w3images/sandwich.jpg';
}

function changeNewImages2() {
  let inContents2 = document.getElementById('img-2');
  inContents2.src = './img/price.png';
}

function backToOldImage2() {
  let inContents2 = document.getElementById('img-2');
  inContents2.src = 'https://www.w3schools.com/w3images/steak.jpg';
}

function changeNewImages3() {
  let inContents3 = document.getElementById('img-3');
  inContents3.src = './img/price.png';
}

function backToOldImage3() {
  let inContents3 = document.getElementById('img-3');
  inContents3.src = 'https://www.w3schools.com/w3images/cherries.jpg';
}

function changeNewImages4() {
  let inContents4 = document.getElementById('img-4');
  inContents4.src = './img/price.png';
}

function backToOldImage4() {
  let inContents4 = document.getElementById('img-4');
  inContents4.src = 'https://www.w3schools.com/w3images/wine.jpg';
}

function changeNewImages5() {
  let inContents4 = document.getElementById('img-5');
  inContents4.src = './img/price.png';
}

function backToOldImage5() {
  let inContents5 = document.getElementById('img-5');
  inContents5.src = 'https://www.w3schools.com/w3images/popsicle.jpg';
}

function changeNewImages6() {
  let inContents6 = document.getElementById('img-6');
  inContents6.src = './img/price.png';
}

function backToOldImage6() {
  let inContents6 = document.getElementById('img-6');
  inContents6.src = 'https://www.w3schools.com/w3images/salmon.jpg';
}

function changeNewImages7() {
  let inContents7 = document.getElementById('img-7');
  inContents7.src = './img/price.png';
}

function backToOldImage7() {
  let inContents7 = document.getElementById('img-7');
  inContents7.src = 'https://www.w3schools.com/w3images/salmon.jpg';
}

function changeNewImages8() {
  let inContents8 = document.getElementById('img-8');
  inContents8.src = './img/price.png';
}

function backToOldImage8() {
  let inContents8 = document.getElementById('img-8');
  inContents8.src = 'https://www.w3schools.com/w3images/croissant.jpg';
}

// Alert event onload
function load() {
  alert("Tugas Pertemuan 9\nMata Kuliah : Pemrograman Internet\nNama : Dimas Anugrah Firdlous\nNIM : 1901010");
}